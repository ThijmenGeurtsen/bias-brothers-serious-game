public class BiasAnswer {


    private char Char;
    private String biasName;
    private String biasDescription;
    private String biasExample;
    private int points;

    public BiasAnswer(String name, String description, String example, int points){
        this.biasName = name;
        this.biasDescription = description;
        this.biasExample = example;
        this.points = points;
    }


}
