import java.util.ArrayList;

public class Canvas {

    public Canvas(){

    }
}
