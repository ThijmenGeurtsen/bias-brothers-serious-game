import com.google.gson.Gson;

import java.io.FileReader;
import java.io.Reader;


public class RoundHandler {

    public String canvasToJsonString(Canvas canvas){
        Gson gson = new Gson();
        String jsonString = gson.toJson(canvas);
        return jsonString;
    }


    public Round loadProfileList(String fName) {
        try {
            Gson gson = new Gson();
            Reader reader = new FileReader(fName);

            Round round = gson.fromJson(reader, Round.class);

            reader.close();

            System.out.println("Round has been loaded");

            return round;
        } catch (Exception e) {

        }
        return null;
    }
}
