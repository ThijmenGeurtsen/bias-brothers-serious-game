import java.util.ArrayList;

public class Round {
    private TitleRound titleRound;
    private int timer;
    private Scenario scenario;
    private ArrayList<Canvas> canvas;
}
