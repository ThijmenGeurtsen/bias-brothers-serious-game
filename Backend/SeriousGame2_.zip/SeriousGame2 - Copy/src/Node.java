public class Node {
    private Canvas canvas;

    private Node rightNode; // is node 0
    private Node middleNode; // is node 1
    private Node leftNode; // is node 3



    public Node(Canvas canvas){
        this.canvas = canvas;
    }

    public void add(Canvas leftCanvas, Canvas middleCanvas, Canvas rightCanvas){
        leftNode = new Node(leftCanvas);
        middleNode = new Node(middleCanvas);
        rightNode = new Node(rightCanvas);
    }


    public boolean checkNodeExists(int nodeNumber){
        if (nodeNumber == 0 && rightNode != null) {
            return true;
        }
        if (nodeNumber == 1 && middleNode != null) {
            return true;
        }
        if (nodeNumber == 2 && leftNode != null) {
            return true;
        }
        return false;
    }

    public Node get(int nodeNumber) {
        try {
            if (nodeNumber == 0) {
                return leftNode;
            }
            if (nodeNumber == 1) {
                return middleNode;
            }
            if (nodeNumber == 2) {
                return rightNode;
            }
        } catch (Exception e) {
        }
        return null;
    }

    public void setNode(int nodeNumber, Canvas canvas){
        if (nodeNumber == 0) {
            setLeftNode(canvas);
        }
        if (nodeNumber == 1) {
            setMiddleNode(canvas);
        }
        if (nodeNumber == 2) {
            setRightNode(canvas);
        }
    }

    public void setRightNode(Canvas canvas){
        this.rightNode = new Node(canvas);
    }

    public void setMiddleNode(Canvas canvas){
        this.middleNode = new Node(canvas);
    }

    public void setLeftNode(Canvas canvas){
        this.leftNode = new Node(canvas);
    }

    public Node getRightNode(){
        return rightNode;
    }

    public Node getMiddleNode(){
        return middleNode;
    }

    public Node getLeftNode(){
        return leftNode;
    }
}

