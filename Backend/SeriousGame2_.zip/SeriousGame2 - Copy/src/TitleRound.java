public class TitleRound {
    private String roundNumber;
    private String title;

    public TitleRound(String roundName, String title){
        this.roundNumber = roundName;
        this.title = title;
    }
}
