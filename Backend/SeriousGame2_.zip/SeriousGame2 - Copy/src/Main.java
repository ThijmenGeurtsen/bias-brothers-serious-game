public class Main {

    public static void main(String[] args){

        DataHandler dataHandler = new DataHandler();
        RoundHandler load = new RoundHandler();
        load.loadProfileList("C:\\Users\\thijm\\IdeaProjects\\SeriousGame2\\src\\data\\R1.json");


        /*

        WhatToDoAnswer answer1 = new WhatToDoAnswer("Een capybara is blauw", true, false, false);
        WhatToDoAnswer answer2 = new WhatToDoAnswer("Een capybara is groen", false, true, false);
        WhatToDoAnswer answer3 = new WhatToDoAnswer("Een capybara is bruin", false, false, true);

        Bias bias1 = new Bias("Anchoring",
                "We laten een eerder beschikbaar gekregen stukje informatie onze latere besluitvorming beïnvloeden. Ondanks dat deze info niet relevant hoeft te zijn. Dit gebeurt vaak als er prijzen of schattingen mee gemoeid zijn.",
                "Wanneer je onderhandelt om prijs is het raadzaam om een absurd openingsbod te negeren. En voordat je zelf een bod plaatst, de tegenpartij een realistisch tegenbod te laten plaatsen. Om te voorkomen dat het eindigt in de buurt van dit absurde eerste bod.");
        Bias bias2 = new Bias("Authority bias",
                "We schatten de mening van een door ons bestempeld autoriteit in als nauwkeuriger en meer 'waar'. Dit is onafhankelijk van onze rationele beoordeling van de boodschap of content. Of mogelijk zelfs onafhankelijk van het expertisegebied van die persoon.",
                        "We nemen van externe consultants met een bepaalde expertise sneller een aanbeveling over. Zelfs als dat buiten het eigen expertisegebied valt.");
        Bias bias3 = new Bias("Backfire effect",
                "We versterken onze eigen overtuigingen juist als we worden geconfronteerd met tegengesteld bewijs.",
                "Neef Fred beweert op een verjaardagsfeestje dat zijn wijk aan het verloederen is. Op het moment dat je hem dalende criminaliteitscijfers laat zien in de afgelopen jaren schudt hij zijn hoofd. Dat zie je toch echt verkeerd. Dat is volgens hem alleen maar bewijs dat onderzoekers hun werk niet goed hebben gedaan.");

        BiasPoint biasPoint1 = new BiasPoint(bias1, 4);
        BiasPoint biasPoint2 = new BiasPoint(bias2, 0);
        BiasPoint biasPoint3 = new BiasPoint(bias3, 10);

        NewsArticle newsArticle1 = new NewsArticle("Degressia sluit grenzen",
                "Om te voorkomen dat Degressia wordt aangestoken met de Olifantengriep heeft het land besloten de grenzen te sluiten. Sinds in haar buurlanden de Olifantengriep is gevonden, treft het land alle voorzorgsmaatregelen om haar inwoners veilig te houden. Onder de inwoners van het land heerst verdeeldheid over de genomen maatregelen.",
                "~ Montangia Mail ~",
                false);


        NewsArticle newsArticle2 = new NewsArticle("Hamsterwoede overvalt ook Digitanzanië",
                "De overheid van Digitanzanië heeft een dashboard gelanceerd waarin alle actuele informatie over de Olifantengriep staat weergegeven. Het dashboard geeft daarnaast aan wat voor stappen burgers kunnen nemen om besmetting met het virus te voorkomen. Zo wordt er geadviseerd om regelmatig de handen te wassen en in de elleboog te niezen.",
                "~ Pretechnostan Post ~",
                true);

        NewsArticle newsArticle3 = new NewsArticle("Olifantengriep wijd verbreid in Noord-Kropslavië",
                "Besmettingen met de Olifantengriep lopen op in Noord-Kropslavië. Gevallen zijn nu geconstateerd in alle grote steden. Het totaal aantal besmettingen is tevens al boven de 5.000 gevallen uitgestegen. Daarbij zijn ook de eerste gevallen van een permanente mutatie gerapporteerd in de hoofdstad. Ziekenhuizen in de provincie zijn druk bezig hun capaciteit op te schalen om het stijgende aantal patiënten aan te kunnen.",
                "~ Degressia Dagblad ~",
                false);

        ArrayList<NewsArticle> newsArticles = new ArrayList<>();

        newsArticles.add(newsArticle1);
        newsArticles.add(newsArticle2);
        newsArticles.add(newsArticle3);

        Scenario scenario = new Scenario("Hamsterwoede!","Met oplopende Olifantengriepcijfers op de horizon zijn inwoners van Engelse Eiland massaal begonnen met het inslaan van tampons. Deze zouden helpen de Olifantengriep uit de neus te houden en daarmee een infectie te voorkomen. De regering van Engelse Eiland verzoekt haar burgers dringend om te stoppen met hamsteren, en verzekert hen ervan dat de voorraden groot genoeg zijn om iedereen te kunnen bedienen. Over de effectiviteit van het tampongebruik als preventie van de Olifantengriep zijn door experts nog geen uitspraken gedaan. In Digitanzanië beginnen de eerste geluiden al op te gaan om spullen in te slaan. Wat moet de overheid doen?");



        Canvas canvas = new Canvas("De start", 0, biasPoint1, biasPoint2, biasPoint3,answer1, answer2, answer3,
                newsArticles,scenario);

        CanvasHandler canvasHandler = new CanvasHandler();
        String sendToFrontEnd = canvasHandler.canvasToJsonString(canvas);
        System.out.println(sendToFrontEnd);




        get("/test", (req,res) -> {
            Gson gson = new Gson();
            return gson.toJson(sendToFrontEnd);
        });


        try (PrintWriter out = new PrintWriter("filename.json")){
            out.println(sendToFrontEnd);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }





         */
    }
}
