import java.util.ArrayList;

public class Tree {

    private Node firstNode;

    public Tree(Canvas parentCanvas){
        firstNode = new Node(parentCanvas);
    }

    public Node getFirstNode(){
        return firstNode;
    }

    public void add(Canvas canvas){
        int childNodes = 3;
        int stepsAllowed = 1;

        Node selectedNode = firstNode;
        ArrayList<Node> previousNodes = new ArrayList<Node>();
        int stepsIntoTree;

        Node emptyNode = null;


        //in this loop a node will be selected that is empty
        while (emptyNode == null){


            //check for a neighbouring
            //if a empty node is found it will set the empty node to the canvas.
            for (int i = 0; i < childNodes; i++){
                if (selectedNode.checkNodeExists(i) == false){
                    emptyNode = new Node(canvas);
                    break;

                }
            }

            break;


        }


    }


}
