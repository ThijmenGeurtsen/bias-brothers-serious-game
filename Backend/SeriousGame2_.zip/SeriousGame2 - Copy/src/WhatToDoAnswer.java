public class WhatToDoAnswer {

    public String question;
    public boolean goLeft;
    public boolean goMiddle;
    public boolean goRight;


    public WhatToDoAnswer(String question, boolean goLeft, boolean goMiddle, boolean goRight){
        this.question = question;
        this.goLeft = goLeft;
        this.goMiddle = goMiddle;
        this.goRight = goRight;
        checkIfOneIsTrue();
    }

    private void checkIfOneIsTrue(){

        int amountTrue = 0;
        if (goLeft == true){
            amountTrue = amountTrue+1;
        }
        if (goMiddle == true){
            amountTrue = amountTrue+1;
        }
        if (goRight == true){
            amountTrue = amountTrue+1;
        }

        if (amountTrue < 1){
            throw new RuntimeException("No correct answer was given");
        }

        if (amountTrue > 1){
            throw new RuntimeException("there were multiple directions given");
        }
    }
}
