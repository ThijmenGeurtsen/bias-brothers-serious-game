public class Scenario {
    private String scenarioTitle;
    private String scenarioText;

    public Scenario(String scenarioTitel, String scenarioTitle){
        this.scenarioTitle = scenarioTitel;
        this.scenarioText = scenarioText;
    }
}
