public class NewsArticle {
    private String newsArticleTitle;
    private String newsArticleMessage;
    private String newsArticleSource;
    private boolean newsArticlePopup;

    int round;

    public NewsArticle(String title, String message, String source, boolean popup, int round){
        this.newsArticleTitle = title;
        this.newsArticleMessage = message;
        this.newsArticleSource = source;
        this.newsArticlePopup = popup;

        this.round = round;
    }

    public int getRound(){
        return round;
    }




}
